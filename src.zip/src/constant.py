#constant of analysis 
AURORA_THREHOLD = 0.034004
MIN_HSV_RANGE = [40, 60, 0]
MAX_HSV_RANGE = [80, 245, 255]
IMAGE_SIZE = 2116800

#constant of SPI communication
MOSI = 19
MISO = 21
SCLK = 23

#constant of order
DATA_SIZE_INDEX = 2