#! /bin/bash

python /home/i-spes/artificial_satellite/src/back_test.py & python /home/i-spes/artificial_satellite/src/front_test.py
